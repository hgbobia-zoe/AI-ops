// The pull. Loaded as a DECLARED content script on pro.goodshuffle.com (see manifest content_scripts),
// so it runs in the page's origin with host access granted at install — NOT injected from the
// background worker (that programmatic injection is what Chrome's per-site permission model kept
// revoking). /app/* fetches carry the operator's Goodshuffle cookies (same-origin) and the POSTs to
// Zoe carry Origin pro.goodshuffle.com, exactly what the ingest endpoints' CORS allows. This mirrors
// the office bookmarklet (src/lib/gsPull.ts buildOfficePullScript); keep the two in sync.
//
// Defines a global `zoePull(apiBase)` in the content-script world; content.js calls it on a timer.
// Stays fully self-contained (every helper nested) so it also works if ever injected directly.

/** @param {string} apiBase Zoe origin, e.g. https://zoe-dispatch.fly.dev
 *  @param {"active"|"full"} [tier] which lane to run. "active" (default) = routes + active projects +
 *   notes + outbox drain (FAST lane, every few minutes, NEVER prunes). "full" = the archive-inclusive
 *   projects history walk (SLOW lane, hourly — the ONLY lane that prunes orphans). */
function zoePull(apiBase, tier) {
  const TIER = tier === "full" ? "full" : "active";
  const API = String(apiBase || "").replace(/\/+$/, "");
  const H = { headers: { "x-requested-with": "XMLHttpRequest", accept: "application/json" }, credentials: "include" };
  const POSTH = { "content-type": "application/json" };
  const AUTH_RE = /\/(ui\/auth|app\/login|login|signin|auth)\b/i;

  // Signed-out probe. Goodshuffle keeps the visible path at "/" but 302s an API call to its auth page
  // when the session is gone (fetch follows it → r.redirected, r.url = /ui/auth), and returns no
  // projectSearch. Checking location.pathname is NOT reliable — verify against the real endpoint.
  function loggedInProbe() {
    return fetch("/app/project/searchProjects?page=0&pageSize=1&allProjects=true&sortColumn=logistics_start_date&sortDirection=desc&useV2DateHandling=true", H)
      .then((r) => { if (r.redirected && AUTH_RE.test(r.url)) return false; if (!r.ok) return false; return r.json().then((j) => !!(j && j.projectSearch)).catch(() => false); })
      .catch(() => false);
  }

  function d2(s) { try { if (!s) return null; const dt = new Date(s); if (isNaN(dt)) return null; return new Date(dt.getTime() - dt.getTimezoneOffset() * 60000).toISOString().slice(0, 10); } catch (e) { return null; } }

  // ---- Bookings feed (projects) → Sales / Finance / Customer ----
  // TWO-TIER: mode="active" pulls ONLY the ~88 active, non-archived projects (searchProjects WITHOUT
  // allProjects, a single page) — the FAST lane that rides with routes/notes/outbox and POSTs
  // scope:"active" (NEVER prunes). mode="full" walks the archive-inclusive history (allProjects=true,
  // paginated) — the SLOW lane that feeds Finance and POSTs scope:"full" (the ONLY scope that prunes).
  function pullProjects(mode) {
    const FULL = mode !== "active"; // default to full for any unexpected value (back-compat / safety)
    const all = {}; let pErr = false;
    function url(pg) { return "/app/project/searchProjects?page=" + pg + "&pageSize=500" + (FULL ? "&allProjects=true" : "") + "&sortColumn=logistics_start_date&sortDirection=desc&useV2DateHandling=true"; }
    function fetchPage(pg) {
      return fetch(url(pg), H)
        .then((r) => { if (!r.ok) throw 0; return r.json(); })
        .then((b) => { const ps = b && b.projectSearch; if (!ps) return { count: 0 }; const res = ps.results || []; res.forEach((p) => { if (p && p.id != null && !all[p.id]) all[p.id] = p; }); return { count: res.length }; })
        .catch(() => { pErr = true; return { count: 0 }; });
    }
    function loop(pg) { return fetchPage(pg).then((r) => { if (FULL && !pErr && r.count > 0 && pg < 60) return loop(pg + 1); return null; }); }
    return loop(0).then(() => {
      const recs = Object.keys(all).map((id) => { const p = all[id];
        return { bookingId: String(p.id), eventName: p.eventName || "", eventDate: d2(p.logistics_start_date), statusLabel: p.statusLabel || "", signed: !!p.signed, archived: !!p.archived, grandTotalCents: p.grand_total, contractTotalCents: p.contract_subtotal, amountPaidCents: p.amount_paid, amountDueCents: p.amount_due, clientName: p.client_name || "", clientEmail: p.client_email || "", clientPhone: p.client_phone || "", quoteSentDate: d2(p.quote_sent_date), dateCreated: d2(p.date_created), venue: p.venueLabel || "", location: p.cityStateZipCounty || "", salesLead: p.salesLeadName || "" };
      });
      if (!recs.length) return { saved: 0, partial: pErr };
      // Capture comms for OPEN leads AND SIGNED near-term deliveries (within today..+3 days), so the driver
      // debrief can read the office's customer-attention notes before delivery day. Union, deduped (open
      // first), capped at 100. MIRRORS selectNoteCaptureIds() in src/lib/gsPull.ts (unit-tested).
      const todayY = new Date().toISOString().slice(0, 10);
      const horizonY = new Date(Date.now() + 3 * 86400000).toISOString().slice(0, 10);
      const openIds = [], signedIds = [];
      Object.keys(all).forEach((id) => { const p = all[id]; const d = d2(p.logistics_start_date);
        if (p.signed) { if (d && d >= todayY && d <= horizonY) signedIds.push(id); return; }
        const s = (p.statusLabel || "").toLowerCase(); if (s.indexOf("lost") >= 0 || s.indexOf("cancel") >= 0 || s.indexOf("dead") >= 0) return;
        if (!d || d >= todayY) openIds.push(id); });
      const seenCap = {}, captureIds = []; openIds.concat(signedIds).forEach((id) => { if (!seenCap[id]) { seenCap[id] = 1; captureIds.push(id); } }); const capIds = captureIds.slice(0, 100);
      function titlesFrom(lists) { const t = []; function w(o, d) { if (!o || typeof o !== "object" || d > 7) return; if (Object.prototype.toString.call(o) === "[object Array]") { for (let k = 0; k < o.length; k++) w(o[k], d + 1); return; } if (o.itemTitle) t.push(o.itemTitle); for (const kk in o) w(o[kk], d + 1); } (lists || []).forEach((gj) => { w(gj, 0); }); return t; }
      // Quote sent/opened from the client email thread (getMessagesForTransaction). sent = earliest
      // outbound quote email; opened = latest client open. Prefer emails whose subject mentions "quote",
      // else any outbound email with client recipients. PARITY with the bookmarklet (gsPull.ts): without
      // this the Pipeline Status shows every open lead as "never contacted / not opened".
      function quoteTimes(mv) {
        const msgs = (mv && mv.client && mv.client.messages) || [];
        let qs = null, qo = null;
        function consider(m) {
          if (m.medium !== "EMAIL") return;
          const recips = m.clientRecipients || [];
          if (!recips.length) return;
          if (m.date && (!qs || m.date < qs)) qs = m.date;
          recips.forEach((rp) => { if (rp.messageOpenedDate && (!qo || rp.messageOpenedDate > qo)) qo = rp.messageOpenedDate; });
        }
        const quoteMsgs = msgs.filter((m) => m.medium === "EMAIL" && (m.clientRecipients || []).length && /quote/i.test(m.subject || ""));
        (quoteMsgs.length ? quoteMsgs : msgs).forEach(consider);
        return { sent: qs, opened: qo };
      }
      // Client EMAIL thread for the lead timeline. PARITY with the bookmarklet (gsPull.ts emailsFrom): without
      // it the extension pull never fed /api/gs/emails, so the timeline (and the morning outreach context)
      // had no Goodshuffle emails at all. FACTS ONLY: id + subject + date + latest open; a snippet only when the
      // message carries a body; direction "outbound" only when it has client recipients, else unknown (null).
      function emailsFrom(mv, id, out) {
        const msgs = (mv && mv.client && mv.client.messages) || [];
        msgs.forEach((m) => {
          if (!m || m.medium !== "EMAIL") return;
          const mid = m.id != null ? String(m.id) : m.messageID != null ? String(m.messageID) : "";
          if (!mid) return;
          const recips = m.clientRecipients || [];
          let opened = null;
          recips.forEach((rp) => { if (rp.messageOpenedDate && (!opened || rp.messageOpenedDate > opened)) opened = rp.messageOpenedDate; });
          const rawBody = m.content || m.body || m.message || m.plainTextBody || m.htmlContent || m.htmlBody || m.preview || "";
          const snip = typeof rawBody === "string" && rawBody ? rawBody.replace(/<[^>]*>/g, " ").replace(/\s+/g, " ").trim().slice(0, 200) : null;
          const participant = recips.length ? recips[0].name || recips[0].email || null : null;
          out.push({ bookingId: String(id), providerMsgId: mid, direction: recips.length ? "outbound" : null, participant, subject: m.subject || null, snippet: snip, occurredAt: m.date || null, openedAt: opened });
        });
      }
      function pullNotes() {
        const notes = [];
        const emails = [];
        function one(i) {
          if (i >= capIds.length) return Promise.resolve();
          const id = capIds[i];
          const pCV = fetch("/app/vendorTransaction/initContractView?transactionID=" + id, H).then((r) => (r.ok ? r.json() : null)).catch(() => null);
          const pMsg = fetch("/app/conversation/getMessagesForTransaction?transactionID=" + id, H).then((r) => (r.ok ? r.json() : null)).catch(() => null);
          return Promise.all([pCV, pMsg]).then((res) => {
            const j = res[0], qt = quoteTimes(res[1]);
            try { emailsFrom(res[1], id, emails); } catch (e) { /* email capture never blocks notes */ }
            if (!j) return; // no contract view → skip (don't blank stored notes with a partial record)
            const g = (j.lineItemGroupsToLoad) || [];
            return Promise.all(g.map((x) => fetch("/app/lineItemGroup/loadContractLineItemGroup?lineItemGroupID=" + x.id + "&transactionID=" + id, H).then((r2) => r2.json()).catch(() => null))).then((lists) => {
              notes.push({ bookingId: String(id), internalNotes: (j.internalNotes || "").trim(), clientNotes: (j.clientVisibleNotes || "").trim(), lastSentDate: null, lineItems: titlesFrom(lists), quoteSentAt: qt.sent, quoteOpenedAt: qt.opened });
            });
          }).catch(() => {}).then(() => one(i + 1));
        }
        return one(0).then(() => {
          const pN = notes.length ? fetch(API + "/api/gs/notes", { method: "POST", headers: POSTH, body: JSON.stringify({ notes }) }).then((r) => r.json()).catch(() => ({ updated: 0 })) : Promise.resolve({ updated: 0 });
          // idempotent server-side on the Goodshuffle message id, so re-posting the thread every pull is safe
          const pE = emails.length ? fetch(API + "/api/gs/emails", { method: "POST", headers: POSTH, body: JSON.stringify({ emails }) }).then((r) => r.json()).catch(() => ({ written: 0 })) : Promise.resolve({ written: 0 });
          return Promise.all([pN, pE]).then((rs) => ({ updated: (rs[0] && rs[0].updated) || 0, emails: (rs[1] && rs[1].written) || 0 }));
        });
      }
      // FULL lane: archive-inclusive POST (scope:"full" — the ONLY scope that prunes) carrying `partial`,
      // no notes (those ride the fast ACTIVE lane). ACTIVE lane: scope:"active" (never prunes) + notes.
      if (FULL) {
        return fetch(API + "/api/gs/projects", { method: "POST", headers: POSTH, body: JSON.stringify({ projects: recs, partial: pErr, scope: "full" }) }).then((r) => r.json()).then((j) => ({ saved: (j && j.saved) || recs.length, partial: pErr || !!(j && j.partial), notes: 0 })).catch(() => ({ saved: 0, partial: true }));
      }
      return fetch(API + "/api/gs/projects", { method: "POST", headers: POSTH, body: JSON.stringify({ projects: recs, scope: "active" }) }).then((r) => r.json()).then((j) => pullNotes().then((nj) => ({ saved: (j && j.saved) || recs.length, partial: false, notes: (nj && nj.updated) || 0 }))).catch(() => ({ saved: 0, partial: false }));
    });
  }

  // ---- Routes feed (today's logistics) → Dispatch / day-of risk ----
  function truckIdFor(title) { const t = (title || "").toLowerCase();
    if (t.indexOf("ford") >= 0 || t.indexOf("e450") >= 0 || t.indexOf("e-450") >= 0) return "E450";
    if (t.indexOf("isuzu") >= 0 || t.indexOf("npr") >= 0) return t.indexOf("2") >= 0 ? "NPR-2" : "NPR-1";
    if (t.indexOf("2") >= 0) return "NPR-2";
    if (t.indexOf("1") >= 0) return "NPR-1";
    return null; }
  // Fallback for a route with no vehicle assigned: match the truck from the route NAME, but only on an
  // explicit truck word (ford/e450/isuzu/npr) + number — never a bare 1/2 (a date digit must not match).
  function truckFromName(name) { const t = (name || "").toLowerCase();
    if (t.indexOf("ford") >= 0 || t.indexOf("e450") >= 0 || t.indexOf("e-450") >= 0) return "E450";
    if (t.indexOf("isuzu") >= 0 || t.indexOf("npr") >= 0) { if (t.indexOf("2") >= 0) return "NPR-2"; if (t.indexOf("1") >= 0) return "NPR-1"; return null; }
    return null; }
  function fetchEvent(txID) { const out = { items: undefined, contactId: undefined, grandTotalCents: undefined, paidCents: undefined, rev: undefined };
    const pI = fetch("/app/vendorTransaction/initContractView?transactionID=" + txID, H).then((r) => r.json())
      .then((cv) => { if (cv && cv.contactID != null) out.contactId = String(cv.contactID); const g = (cv && cv.lineItemGroupsToLoad) || []; return Promise.all(g.map((x) => fetch("/app/lineItemGroup/loadContractLineItemGroup?lineItemGroupID=" + x.id + "&transactionID=" + txID, H).then((r) => r.json()).catch(() => null))); })
      .then((lists) => { const items = [];
        // Item photo for the driver load list. The image lives on the inventory item as
        // item.thumbImagePath (a public CloudFront/S3 URL) — already in loadContractLineItemGroup, so no
        // extra fetch. imgFrom matches any image/photo/thumb/picture key; imageOf also checks o.item.
        const absUrl = (u) => { if (!u || typeof u !== "string") return null; const s = u.toLowerCase(); if (s.startsWith("http://") || s.startsWith("https://")) return u; if (u.slice(0, 2) === "//") return "https:" + u; if (u[0] === "/") return "https://pro.goodshuffle.com" + u; return null; };
        const imgFrom = (o) => { if (!o || typeof o !== "object") return null; for (const k in o) { if (/image|photo|thumb|picture/i.test(k)) { const v = o[k]; const a = absUrl(v); if (a) return a; if (v && typeof v === "object") { const au = absUrl(v.url) || absUrl(v.path) || absUrl(v.src) || absUrl(v.thumbUrl) || absUrl(v.thumbnailUrl); if (au) return au; } } } return null; };
        const imageOf = (o) => { const d0 = imgFrom(o); if (d0) return d0; const n = o.item || o.inventoryItem || o.itemData; if (n && typeof n === "object") { const u = imgFrom(n); if (u) return u; } return null; };
        function w(o, d) { if (!o || typeof o !== "object" || d > 7) return; if (Object.prototype.toString.call(o) === "[object Array]") { for (let i = 0; i < o.length; i++) w(o[i], d + 1); return; } if (o.itemTitle) { const it = { name: o.itemTitle, quantity: o.quantityBooked }; const im = imageOf(o); if (im) it.image = im; items.push(it); } for (const k in o) w(o[k], d + 1); } (lists || []).forEach((gj) => { w(gj, 0); }); if (items.length) out.items = items; })
      .catch(() => {});
    const pR = fetch("/app/vendorPayment/loadPaymentHistoryAndContractTotals?transactionID=" + txID, H).then((r) => r.json())
      .then((pt) => { if (pt && typeof pt.grandTotal === "number") out.grandTotalCents = pt.grandTotal; const ph = pt && pt.paymentHistory; if (ph && typeof ph.totalContractApplicablePaid === "number") out.paidCents = ph.totalContractApplicablePaid;
        // Stage 3 revenue reconstruction: carry the full component breakdown (CENTS) off the SAME response.
        // MIRRORS extractRevenueComponents() in src/lib/finance/revenueModel.ts (inline here — drift caught in review).
        if (pt) { const N = (v) => (typeof v === "number" && isFinite(v)) ? v : null;
          let rt = null; const etr = pt.effectiveTaxRate; if (typeof etr === "number" && isFinite(etr)) rt = etr; else if (typeof etr === "string" && etr.trim() !== "") { const pf = Number(etr); if (isFinite(pf)) rt = pf; }
          const evs = (ph && ph.paymentEvents && ph.paymentEvents.length) ? ph.paymentEvents : []; let gsf = null; for (let gi = 0; gi < evs.length; gi++) { const gv = N(evs[gi] && evs[gi].goodshuffleFeeAmount); if (gv != null) gsf = (gsf == null ? 0 : gsf) + gv; }
          const opf = N(ph && ph.onlinePaymentsProcessingFeesTotal), ffp = N(ph && ph.offlinePaymentsProcessingFeesTotal); const pfees = (opf == null && ffp == null) ? null : ((opf || 0) + (ffp || 0));
          out.rev = { bookingId: String(txID), quotedSubtotal: N(pt.contractOriginalSubTotal), contractTotal: N(pt.contractTotal), grandTotal: N(pt.grandTotal), productSubtotal: N(pt.contractProductSubTotal), productRentalsSubtotal: N(pt.contractProductRentalsSubTotal), productSalesSubtotal: N(pt.contractProductSalesSubTotal), serviceSubtotal: N(pt.contractServiceSubTotal), logisticsSubtotal: N(pt.contractLogisticsSubTotal), detachedItemSubtotal: N(pt.contractDetachedItemSubTotal), discount: N(pt.contractDiscount), additionalDiscount: N(pt.contractAdditionalDiscount), discountSubtotal: N(pt.contractDiscountSubTotal), taxableSubtotal: N(pt.contractTaxableSubTotal), taxTotal: N(pt.taxMap && pt.taxMap.total), effectiveTaxRate: rt, collected: N(ph && ph.totalContractApplicablePaid), refunds: N(ph && ph.totalSuccessfulRefunds), processingFees: pfees, goodshuffleFees: gsf }; }
      })
      .catch(() => {});
    return Promise.all([pI, pR]).then(() => out); }
  function extractStops(route) { const wps = (route.waypoints || []).filter((w) => !w.isOriginWarehouse && !w.isDestinationWarehouse); wps.sort((a, b) => (a.waypointIndex || 0) - (b.waypointIndex || 0));
    return wps.map((w) => { const tl = (w.logisticRelation && w.logisticRelation.targetLocation) || {}; const tx = w.transaction || {}; const line = [tl.streetAddressLine1, tl.streetAddressLine2].filter(Boolean).join(" "); const cs = [tl.city, tl.state].filter(Boolean).join(", "); const address = [line, cs, tl.zipCode].filter(Boolean).join(", "); const r = tx.renter || {}; const sv = r.smsValidation || {}; const name = tl.contactName || (tx.eventName ? String(tx.eventName).split(" - ")[0].trim() : "") || r.name; const doc = tx.dayOfContact || null;
      const s = { custName: name || "", custFirstName: r.firstName || undefined, custLastName: r.lastName || undefined, kind: (w.waypointType === "PICK_UP" ? "pickup" : "delivery"), custPhone: sv.e164PhoneNumber || r.phone || tl.contactPhoneNumber || "", address, plannedWindow: w.scheduledArrivalTime || undefined, eta: w.scheduledArrivalTime || undefined };
      if (doc) { s.dayOfName = doc.name || doc.fullName || undefined; s.dayOfPhone = doc.phoneNumber || doc.phone || undefined; }
      s._txID = w.transactionID || (tx && tx.id) || null; if (s._txID) s.txId = String(s._txID); return s; }); }
  function attachItems(stops) { return Promise.all(stops.map((s) => { if (!s._txID) { delete s._txID; return Promise.resolve(); } return fetchEvent(s._txID).then((ev) => { if (ev) { if (ev.items && ev.items.length) s.items = ev.items; if (ev.contactId) s.contactId = ev.contactId; if (ev.grandTotalCents != null) s.grandTotalCents = ev.grandTotalCents; if (ev.paidCents != null) s.paidCents = ev.paidCents; if (ev.rev) s.revComponents = ev.rev; } delete s._txID; }); })).then(() => stops); }
  // Multi-week route pull: the next ~3 weeks, imported per (truck, DATE) so the dispatch calendar +
  // risk engine stay populated ahead. Near-term routes (<= ENRICH days) get full per-event enrichment
  // (line items → tent/crew rules); farther-out routes import bare stops to keep the pull fast.
  function pullRoutes() {
    const HORIZON = 21, ENRICH = 8;
    const now = new Date(); const start = new Date(now.getFullYear(), now.getMonth(), now.getDate(), 0, 0, 0); const end = new Date(start.getTime() + (HORIZON + 1) * 24 * 3600 * 1000);
    const todayYmd = d2(start.toISOString());
    const body = { from: start.toISOString(), to: end.toISOString(), warehouseCanonicalIDs: null, crew: null, vehicles: null, statuses: null };
    return fetch("/app/routing/listRoutes", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify(body), credentials: "include" }).then((r) => r.json()).then((routes) => {
      const groups = {}; let chain = Promise.resolve(); const unmatched = {}; const revAcc = {};
      (routes || []).forEach((rt) => { chain = chain.then(() => { const title = (rt.vehicle && rt.vehicle.title) || ""; const tid = truckIdFor(title) || truckFromName(rt.name); if (!tid) { if (title || rt.name) unmatched[title || rt.name] = 1; return; }
        return fetch("/app/routing/getRoute?routeID=" + rt.id + "&includeAttributes=true", { headers: { accept: "application/json" }, credentials: "include" }).then((r) => r.json()).then((full) => {
          const stops = extractStops(full);
          const rdate = d2(rt.startDate) || d2(rt.date) || (stops[0] ? d2(stops[0].eta) : null);
          if (!rdate) return;
          const daysOut = Math.round((Date.parse(rdate + "T00:00:00Z") - Date.parse(todayYmd + "T00:00:00Z")) / 86400000);
          const p = daysOut >= 0 && daysOut <= ENRICH ? attachItems(stops) : Promise.resolve(stops);
          return p.then((st) => { const key = tid + "|" + rdate + "|" + rt.id; if (!groups[key]) groups[key] = { truckId: tid, date: rdate, stops: [], gsRouteId: String(rt.id) }; groups[key].stops = groups[key].stops.concat(st);
            // Stage 3: collect each enriched stop's revenue component breakdown (CENTS), deduped by tx.
            st.forEach((x) => { if (x && x.revComponents && x.revComponents.bookingId) revAcc[x.revComponents.bookingId] = x.revComponents; }); });
        }); }); });
      return chain.then(() => {
        const keys = Object.keys(groups); let totalStops = 0, failed = 0; const days = keys.length; const unm = Object.keys(unmatched);
        const result = () => ({ stops: totalStops, days, failed, unmatched: unm });
        // Stage 3: push the enriched revenue component breakdown to the bookings SoT ingest (components-only
        // POST — no projects[], so it never touches the bookings upsert/prune). Best-effort; never fails the pull.
        const postComponents = () => { const vals = Object.keys(revAcc).map((k) => revAcc[k]); if (!vals.length) return Promise.resolve(); return fetch(API + "/api/gs/projects", { method: "POST", headers: POSTH, body: JSON.stringify({ components: vals }) }).then(() => {}).catch(() => {}); };
        return Promise.all(keys.map((k) => { const g = groups[k]; totalStops += g.stops.length; return fetch(API + "/api/route/import", { method: "POST", headers: POSTH, body: JSON.stringify({ truckId: g.truckId, date: g.date, stops: g.stops, gsRouteId: g.gsRouteId }) }).then((r) => { if (!r.ok) failed++; }).catch(() => { failed++; }); })).then(postComponents).then(() => {
          // Sanitize: after a FULL clean sweep, drop any of OUR routes GS no longer has. Never on a partial pull.
          if (failed !== 0 || keys.length === 0) return result();
          const keepRouteIds = keys.map((k) => { const g = groups[k]; return "R-" + g.date + "-" + g.truckId + "-" + g.gsRouteId; });
          const dset = {}; keys.forEach((k) => { dset[groups[k].date] = 1; });
          return fetch(API + "/api/route/prune", { method: "POST", headers: POSTH, body: JSON.stringify({ dates: Object.keys(dset), keepRouteIds }) }).then(() => result()).catch(() => result());
        });
      });
    }).catch(() => ({ stops: 0, days: 0, failed: 1, unmatched: [] }));
  }

  // ---- Goodshuffle email template renderer: VERBATIM copy of GS_TEMPLATE_JS (src/lib/intake/gsTemplate.ts);
  // a test checks the copy, so change it there and paste it here. ----
  function gsRenderTemplate(html, tags) {
  var vals = {};
  (tags || []).forEach(function (t) { if (t && t.name) vals[String(t.name).replace(/\s+/g, "").toLowerCase()] = t.transactionValue; });
  var FALLBACK = { firstname: "there" };
  var esc = function (s) { return String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;"); };
  var src = String(html || ""), out = "", i = 0, m;
  var re = /<span\b[^>]*class="[^"]*\bmention\b[^"]*"[^>]*>/gi;
  while ((m = re.exec(src))) {
    var open = m[0], start = m.index, j = start + open.length, depth = 1, t;
    var tagRe = /<\/?span\b[^>]*>/gi;
    tagRe.lastIndex = j;
    while (depth > 0 && (t = tagRe.exec(src))) { depth += t[0].charAt(1) === "/" ? -1 : 1; j = tagRe.lastIndex; }
    var km = /data-original="([^"]*)"/i.exec(open) || /data-value="([^"]*)"/i.exec(open);
    var key = km ? km[1].replace(/\s+/g, "").toLowerCase() : "";
    var v = vals[key];
    if (v == null || v === "") v = FALLBACK[key] || "";
    out += src.slice(i, start) + esc(v);
    i = j;
    re.lastIndex = j;
  }
  return out + src.slice(i);
}
function gsTemplateText(html) {
  return String(html || "").replace(/<br\s*\/?>/gi, " ").replace(/<\/(div|p|li)>/gi, " ").replace(/<[^>]+>/g, "")
    .replace(/&nbsp;/g, " ").replace(/&lt;/g, "<").replace(/&gt;/g, ">").replace(/&quot;/g, '"').replace(/&amp;/g, "&")
    .replace(/\s+/g, " ").trim();
}

  // ---- Outbox drain: push queued Dispatch → Goodshuffle writes (photos, note appends) ----
  function ackOp(id, ok, err) { return fetch(API + "/api/gs/outbox", { method: "POST", headers: POSTH, body: JSON.stringify({ id, ok, error: ok ? undefined : err }) }).catch(() => {}); }
  // Sender hold: Goodshuffle sends an email as whoever is signed in, so client emails go out only from the
  // configured sender's session (server's emailSender, e.g. "Jessie Medalla"). Any other session leaves them
  // pending. The signed-in user comes from /app/rms/initHeader (currentUser firstName/lastName/email).
  function gsNorm(s) { return String(s || "").trim().toLowerCase().replace(/\s+/g, " "); }
  function gsSignedInAs(sender) {
    return fetch("/app/rms/initHeader", { headers: { "x-requested-with": "XMLHttpRequest", accept: "application/json" }, credentials: "include" })
      .then((r) => (r.ok ? r.json() : null)).then((h) => {
        const u = h && h.currentUser; if (!u) return false;
        const want = gsNorm(sender);
        return want.indexOf("@") >= 0 ? gsNorm(u.email) === want : gsNorm((u.firstName || "") + " " + (u.lastName || "")) === want;
      }).catch(() => false);
  }
  function drainOutbox() {
    // senderHold=1 tells the server this copy enforces the sender hold; older copies get no email ops.
    return fetch(API + "/api/gs/outbox?senderHold=1", { headers: POSTH }).then((r) => r.json()).then((j) => {
      const all = (j && j.ops) || [];
      const photoOps = all.filter((o) => o.op === "photo_upload" && o.transactionId && o.payload && o.payload.photoIds && o.payload.photoIds.length);
      const noteOps = all.filter((o) => o.op === "note_append" && o.transactionId && o.payload && o.payload.line);
      const teamOps = all.filter((o) => o.op === "add_team_member" && o.transactionId && o.payload && o.payload.userID);
      const feeOps = all.filter((o) => o.op === "set_delivery_fee" && o.transactionId && o.payload && o.payload.amount != null);
      const emailOps = all.filter((o) => o.op === "email_send" && o.transactionId && o.payload && o.payload.content);
      const tplOps = all.filter((o) => o.op === "email_template" && o.transactionId && o.payload && (o.payload.templateName || o.payload.templateId));
      const taskOps = all.filter((o) => o.op === "create_gs_task" && o.transactionId && o.payload && o.payload.title);
      const provOps = all.filter((o) => (o.op === "provision_user" || o.op === "revoke_user") && o.payload && o.payload.system);
      const esignOps = all.filter((o) => o.op === "disable_esignature" && o.transactionId);
      const lostOps = all.filter((o) => o.op === "mark_lost" && o.transactionId);
      // Ops this content-script drainer can't action (e.g. create_project, which needs a popup created
      // from a real user gesture — a timer-driven content script has none, so the office bookmarklet or a
      // Playwright runner drains those). Surfaced in the result so they're VISIBLE, never silently
      // ignored forever. Keep this set in sync with the handlers below + gsPull.ts.
      const HANDLED = { photo_upload: 1, note_append: 1, add_team_member: 1, set_delivery_fee: 1, email_send: 1, email_template: 1, create_gs_task: 1, provision_user: 1, revoke_user: 1, disable_esignature: 1, mark_lost: 1 };
      const unhandledOps = all.filter((o) => !HANDLED[o.op]);
      const emailSender = (j && j.emailSender) || null;
      let senderOk = !emailSender, emailsHeld = 0;
      let pushed = 0, failed = 0, notes = 0, team = 0, fees = 0, emails = 0, tasks = 0, provisioned = 0, esigns = 0, losts = 0;
      let chain = (emailSender && (emailOps.length || tplOps.length)) ? gsSignedInAs(emailSender).then((ok) => { senderOk = ok; }) : Promise.resolve();
      // provision_user / revoke_user: People Lifecycle access provisioning via REPLAY. Mirrors
      // src/lib/gsPull.ts — gated on the captured endpoint (src/lib/people/provisioningEndpoints.ts). This
      // content script runs ONLY on pro.goodshuffle.com, so it can replay the GOODSHUFFLE invite/disable once
      // that endpoint is captured; Quo/Slack drain from their own logged-in session. CAPTURE-PENDING: both
      // are null until the internal request is recorded once from a logged-in GSPRO admin session and the
      // endpoint+body are filled in provisioningEndpoints.ts (keep this constant in sync).
      const GS_PROVISION = { provision: null, revoke: null };
      provOps.forEach((o) => { chain = chain.then(() => {
        if (o.payload.system !== "goodshuffle") return; // only Goodshuffle shares this origin; skip others
        const ep = (o.op === "provision_user") ? GS_PROVISION.provision : GS_PROVISION.revoke;
        if (!ep || !ep.path) return; // CAPTURE-PENDING: no-op until the endpoint is captured (leave pending)
        const data = o.payload.data || {}; const headers = { "x-requested-with": "XMLHttpRequest", accept: "application/json" }; let body;
        if (ep.bodyType === "form") { headers["content-type"] = "application/x-www-form-urlencoded"; body = new URLSearchParams(data).toString(); }
        else { headers["content-type"] = "application/json"; body = JSON.stringify(data); }
        return fetch(ep.path, { method: ep.method, headers, credentials: "include", body: (ep.method === "DELETE" ? undefined : body) }).then((r) => r.ok).then((ok) => { if (ok) provisioned++; else failed++; return ackOp(o.id, ok, o.op + "_failed"); }).catch(() => { failed++; return ackOp(o.id, false, o.op + "_error"); });
      }); });
      // add_team_member: add a GSPRO user (e.g. Warehouse Desktop) to the project's team.
      teamOps.forEach((o) => { chain = chain.then(() => {
        const body = new URLSearchParams({ transactionID: String(o.transactionId), userID: String(o.payload.userID), linkType: String(o.payload.linkType || "OTHER") });
        return fetch("/app/project/addNewTeamMember", { method: "POST", headers: { "x-requested-with": "XMLHttpRequest", "content-type": "application/x-www-form-urlencoded", accept: "application/json" }, credentials: "include", body }).then((r) => r.ok).then((ok) => { if (ok) team++; else failed++; return ackOp(o.id, ok, "add_team_member_failed"); }).catch(() => { failed++; return ackOp(o.id, false, "add_team_member_error"); });
      }); });
      photoOps.forEach((o) => { chain = chain.then(() => {
        let ok = Promise.resolve(true);
        o.payload.photoIds.forEach((pid) => { ok = ok.then((soFar) => { if (!soFar) return false;
          return fetch(API + "/api/pod/" + encodeURIComponent(pid)).then((r) => { if (!r.ok) throw 0; return r.blob(); }).then((blob) => { const fd = new FormData(); fd.append("file", blob, pid); return fetch("/app/files/uploadFileToProject?transactionID=" + encodeURIComponent(o.transactionId), { method: "POST", body: fd, credentials: "include" }).then((r) => r.ok); }).catch(() => false);
        }); });
        return ok.then((doneOk) => { if (doneOk) pushed++; else failed++; return ackOp(o.id, doneOk, "photo_upload_failed"); });
      }); });
      noteOps.forEach((o) => { chain = chain.then(() => {
        return fetch("/app/vendorTransaction/initContractView?transactionID=" + encodeURIComponent(o.transactionId), { headers: { "x-requested-with": "XMLHttpRequest", accept: "application/json" }, credentials: "include" }).then((r) => { if (!r.ok) throw 0; return r.json(); }).then((cv) => {
          const cur = cv.internalNotes || ""; const newInt = (cur ? cur + "\n\n" : "") + o.payload.line;
          const body = new URLSearchParams({ transactionID: String(o.transactionId), clientVisibleNotes: cv.clientVisibleNotes || "", internalNotes: newInt, fulfillmentNotes: cv.fulfillmentNotes || "" });
          return fetch("/app/vendorTransaction/saveEventNotes", { method: "POST", headers: { "x-requested-with": "XMLHttpRequest", "content-type": "application/x-www-form-urlencoded", accept: "application/json" }, credentials: "include", body }).then((r) => r.ok);
        }).then((ok) => { if (ok) notes++; else failed++; return ackOp(o.id, ok, "note_append_failed"); }).catch(() => { failed++; return ackOp(o.id, false, "note_append_error"); });
      }); });
      // set_delivery_fee: override the project's Standard Delivery line(s) with our computed per-leg fee.
      // Load the contract's line item groups, find every base Standard Delivery line (inventory item
      // 392868144), and re-save each via saveInventoryTrackedLineItemEdit with unitPriceOverridden=true +
      // our unitPrice, mileageFee 0. Every other field is echoed from the line as loaded (venue, dates,
      // marker) so nothing else changes. Skips (acks failure) when the project has no Standard Delivery line.
      feeOps.forEach((o) => { chain = chain.then(() => {
        const tx = o.transactionId, amount = o.payload.amount, DELIV = 392868144;
        const ymd = (raw) => { if (!raw) return null; const s = String(raw); return (s.length >= 10 && s[4] === "-" && s[7] === "-") ? s.slice(0, 10) : null; };
        const findDeliv = (li) => { const out = []; (function w(n) { if (!n || typeof n !== "object") return; if (Array.isArray(n)) { n.forEach(w); return; } if (n.itemTitle && n.item && String(n.item.id) === String(DELIV)) out.push(n); for (const k in n) w(n[k]); })(li); return out; };
        const saveLeg = (gid, n) => { const it = n.item || {}, tl = n.targetLocation || {}; const body = { inventoryInjection: true, itemID: it.id, fulfillment: false, transactionID: Number(tx) || tx, lineItemGroupID: gid, parentRelationID: null, relationID: n.id, relationType: null, inventoryTypeStr: it.inventoryType || "SERVICE", rateType: n.rateType || "FLAT_FEE_WITH_MILEAGE", title: n.itemTitle || "Standard Delivery", description: null, isSubrental: false, internalNotes: n.internalNotes || "", showItemDescription: true, showItemAttributes: true, quantity: n.quantityBooked || 1, unitPriceOverridden: true, unitPrice: String(amount), mileageFee: 0, discountDollarAmount: 0, discountPercentage: 0, itemStartDate: ymd(n.rawStartDate), itemStartTime: null, itemEndDate: ymd(n.rawEndDate), itemEndTime: null, itemHoursRented: null, eventTimeLineMarker: n.eventTimeLineMarker || null, selectedTaxTypes: [], serviceStoreLocationID: null, venueName: tl.venueName || null, venueAddress: tl.streetAddressLine1 || null, venueAddress_line2: tl.streetAddressLine2 || null, venueAddress_city: tl.city || null, venueAddress_state: tl.state || null, venueAddress_zipCode: tl.zipCode || null, venueAddress_county: tl.county || null, venueAddress_country: tl.country || null, venueAddress_latitude: tl.latitude || null, venueAddress_longitude: tl.longitude || null, images: [] }; return fetch("/app/transactionItemRelation/saveInventoryTrackedLineItemEdit", { method: "POST", headers: { "content-type": "application/json", "x-requested-with": "XMLHttpRequest", accept: "application/json" }, credentials: "include", body: JSON.stringify(body) }).then((r) => r.ok); };
        return fetch("/app/vendorTransaction/initContractView?transactionID=" + encodeURIComponent(tx), { headers: { "x-requested-with": "XMLHttpRequest", accept: "application/json" }, credentials: "include" }).then((r) => { if (!r.ok) throw 0; return r.json(); }).then((cv) => {
          const groups = (cv && cv.lineItemGroupsToLoad) || []; const legs = []; let gchain = Promise.resolve();
          groups.forEach((g) => { gchain = gchain.then(() => fetch("/app/lineItemGroup/loadContractLineItemGroup?lineItemGroupID=" + g.id + "&transactionID=" + encodeURIComponent(tx), { headers: { "x-requested-with": "XMLHttpRequest", accept: "application/json" }, credentials: "include" }).then((r) => r.json()).then((li) => { findDeliv(li).forEach((n) => legs.push({ gid: g.id, n })); }).catch(() => {})); });
          return gchain.then(() => { if (!legs.length) throw "no_delivery_line"; let s = Promise.resolve(true); legs.forEach((L) => { s = s.then((ok) => ok ? saveLeg(L.gid, L.n) : false); }); return s; });
        }).then((ok) => { if (ok) fees++; else failed++; return ackOp(o.id, ok, "set_delivery_fee_failed"); }).catch((e) => { failed++; return ackOp(o.id, false, "set_delivery_fee_" + (typeof e === "string" ? e : "error")); });
      }); });
      // email_send: reply into the project's CLIENT email thread (continues it; Goodshuffle appends the
      // signature). Read the thread, take the latest message's id + recipients + subject, POST sendMessage.
      // PARITY with the bookmarklet (gsPull.ts) — without this handler an APPROVED email reply was stamped
      // "executed" upstream but sat in the outbox forever (never actually sent) whenever this extension was
      // the active drainer. Pure fetch, no popup, so it runs fine on the drain timer.
      emailOps.forEach((o) => { chain = chain.then(() => {
        if (!senderOk) { emailsHeld++; return; } // not the sender's session: leave it pending
        return fetch("/app/conversation/getMessagesForTransaction?transactionID=" + encodeURIComponent(o.transactionId), { headers: { "x-requested-with": "XMLHttpRequest", accept: "application/json" }, credentials: "include" }).then((r) => { if (!r.ok) throw 0; return r.json(); }).then((cv) => {
          const msgs = (cv && cv.client && cv.client.messages) || [];
          if (!msgs.length) throw "no_thread";
          const last = msgs[msgs.length - 1];
          const recips = (last.clientRecipients || []).map((rp) => ({ contactID: rp.contactID, email: rp.email, name: rp.name, phone: rp.phone, isCurrentUser: !!rp.isCurrentUser, isEmailValid: true, deliveryConfirmedDate: null, messageOpenedDate: null, hardBouncedDate: null, droppedMessageDate: null }));
          if (!recips.length) throw "no_recipient";
          let subj = (o.payload.subject || last.subject || "");
          if (!/^re:/i.test(subj)) subj = "Re: " + subj;
          let txID = Number(o.transactionId); if (!txID) txID = o.transactionId;
          const payload = { messageID: last.id, transactionID: txID, content: o.payload.content, recipients: recips, subject: subj, messageType: "CLIENT", attachments: [] };
          return fetch("/app/conversation/sendMessage", { method: "POST", headers: { "content-type": "application/json", "x-requested-with": "XMLHttpRequest", accept: "application/json" }, credentials: "include", body: JSON.stringify(payload) }).then((r) => r.ok);
        }).then((ok) => { if (ok) emails++; else failed++; return ackOp(o.id, ok, "email_send_failed"); }).catch((e) => { failed++; return ackOp(o.id, false, "email_send_" + (typeof e === "string" ? e : "error")); });
      }); });
      // email_template: send a Goodshuffle email TEMPLATE (e.g. the web-lead welcome) as a NEW client email.
      // The template list for this project comes back with every variable filled in (templateTags[].
      // transactionValue); gsRenderTemplate swaps the #variable chips for those values. Recipients are the
      // project's client participants (present even before any message). If an email with the same subject
      // is already in the client thread (an earlier send whose ack was lost), it acks done without sending.
      tplOps.forEach((o) => { chain = chain.then(() => {
        if (!senderOk) { emailsHeld++; return; } // not the sender's session: leave it pending
        const GH = { headers: { "x-requested-with": "XMLHttpRequest", accept: "application/json" }, credentials: "include" };
        const tx = o.transactionId; let txID = Number(tx); if (!txID) txID = tx;
        let tpl = null;
        return fetch("/app/messageTemplate/list?transactionID=" + encodeURIComponent(tx), GH).then((r) => { if (!r.ok) throw "template_list_" + r.status; return r.json(); }).then((j) => {
          const want = String(o.payload.templateName || "").trim().toLowerCase();
          tpl = ((j && j.templates) || []).filter((t) => (o.payload.templateId && String(t.id) === String(o.payload.templateId)) || (want && String(t.name || "").trim().toLowerCase() === want))[0] || null;
          if (!tpl) throw "template_not_found";
          if (tpl.medium && tpl.medium !== "EMAIL") throw "template_not_email";
          return fetch("/app/conversation/getMessagesForTransaction?transactionID=" + encodeURIComponent(tx), GH);
        }).then((r) => { if (!r.ok) throw "thread_" + r.status; return r.json(); }).then((cv) => {
          const subject = gsTemplateText(gsRenderTemplate(tpl.subject, tpl.templateTags));
          const content = gsRenderTemplate(tpl.content, tpl.templateTags);
          if (!subject || !gsTemplateText(content)) throw "template_empty";
          const msgs = (cv && cv.client && cv.client.messages) || [];
          if (msgs.some((m) => gsTemplateText(m.subject) === subject)) return true; // already sent
          const recips = ((cv && cv.client && cv.client.participants) || []).filter((p) => p && p.email).map((p) => ({ contactID: p.contactID, email: p.email, name: p.name, isCurrentUser: false, isEmailValid: true, deliveryConfirmedDate: null, messageOpenedDate: null, hardBouncedDate: null, droppedMessageDate: null }));
          if (!recips.length) throw "no_recipient";
          const payload = { messageID: null, templateID: tpl.id, transactionID: txID, content, recipients: recips, subject, messageType: "CLIENT", attachments: (tpl.attachments || []).map((a) => a && a.id).filter(Boolean) };
          return fetch("/app/conversation/sendMessage", { method: "POST", headers: { "content-type": "application/json", "x-requested-with": "XMLHttpRequest", accept: "application/json" }, credentials: "include", body: JSON.stringify(payload) }).then((r) => r.ok);
        }).then((ok) => { if (ok) emails++; else failed++; return ackOp(o.id, ok, "email_template_failed"); }).catch((e) => { failed++; return ackOp(o.id, false, "email_template_" + (typeof e === "string" ? e : "error")); });
      }); });
      // create_gs_task: queue a to-do on the GSPRO project. Form-urlencoded POST /app/task/createTask
      // (captured + verified live in gsPull.ts). On success ack; on FAILURE leave the op PENDING (no ack)
      // so it retries next cycle, mirroring the bookmarklet.
      const GS_MON = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
      const gsDueStr = () => { const d = new Date(); return GS_MON[d.getMonth()] + " " + d.getDate() + " " + d.getFullYear(); };
      taskOps.forEach((o) => { chain = chain.then(() => {
        let text = String(o.payload.title || ""); if (o.payload.note) text += " — " + String(o.payload.note);
        const body = new URLSearchParams({ taskID: "", taskText: text, taskAssignedTransactionID: String(o.transactionId), taskAssignedUserID: "", taskDueDateStr: gsDueStr(), fromProjectView: "true" });
        return fetch("/app/task/createTask", { method: "POST", headers: { "x-requested-with": "XMLHttpRequest", "content-type": "application/x-www-form-urlencoded", accept: "application/json" }, credentials: "include", body }).then((r) => r.ok).then((ok) => { if (ok) { tasks++; return ackOp(o.id, true); } /* leave PENDING on failure so it retries */ }).catch(() => { /* leave PENDING; never disrupt the rest of the drain */ });
      }); });
      // disable_esignature: turn OFF online signing on the project N business days before the event, so the
      // contract signs IN PERSON (queued by src/lib/salesos/esignCutoff.ts). CAPTURE-NEEDED: the Goodshuffle
      // internal request that disables online signing has NOT been captured yet. Do the toggle ONCE in the
      // GSPRO UI on a TEST project while recording the browser network tab, then fill GS_DISABLE_ESIGN below
      // (method + path + bodyType "form"|"json" + a body builder from the transactionId). Until then this is
      // a NO-OP that leaves the op PENDING — it NEVER fabricates/guesses a request (honest-when-unobservable).
      // Keep this constant + the body shape in sync with src/lib/gsPull.ts (bookmarklet parity).
      const GS_DISABLE_ESIGN = null; // e.g. { method:"POST", path:"/app/vendorTransaction/…", bodyType:"form", body:(tx)=>({ transactionID:String(tx), /* captured field */ }) }
      esignOps.forEach((o) => { chain = chain.then(() => {
        if (!GS_DISABLE_ESIGN || !GS_DISABLE_ESIGN.path) return; // CAPTURE-PENDING: leave pending, no request
        const ep = GS_DISABLE_ESIGN; const data = ep.body ? ep.body(o.transactionId) : { transactionID: String(o.transactionId) };
        const headers = { "x-requested-with": "XMLHttpRequest", accept: "application/json" }; let body;
        if (ep.bodyType === "json") { headers["content-type"] = "application/json"; body = JSON.stringify(data); }
        else { headers["content-type"] = "application/x-www-form-urlencoded"; body = new URLSearchParams(data).toString(); }
        return fetch(ep.path, { method: ep.method || "POST", headers, credentials: "include", body }).then((r) => r.ok).then((ok) => { if (ok) esigns++; else failed++; return ackOp(o.id, ok, "disable_esignature_failed"); }).catch(() => { failed++; return ackOp(o.id, false, "disable_esignature_error"); });
      }); });
      // mark_lost: an unsigned quote 3 days (or less) before its event (queued by the Sales Bot morning run,
      // src/lib/salesos/markLost.ts). Captured live 2026-11-03 on TEST 3: POST markAsLost then archiveProject,
      // each a form body of just transactionID. Done only when both succeed; a failure acks failed (visible
      // in the outbox health) rather than retrying a half done write forever.
      lostOps.forEach((o) => { chain = chain.then(() => {
        const post = (path) => fetch(path, { method: "POST", headers: { "x-requested-with": "XMLHttpRequest", "content-type": "application/x-www-form-urlencoded", accept: "application/json" }, credentials: "include", body: new URLSearchParams({ transactionID: String(o.transactionId) }).toString() }).then((r) => r.ok);
        return post("/app/vendorTransaction/markAsLost").then((lostOk) => {
          if (o.payload && o.payload.archive === false) return lostOk ? "" : "lost_failed";
          return post("/app/vendorTransaction/archiveProject").then((archOk) => (lostOk && archOk ? "" : !lostOk ? "lost_failed" : "archive_failed"));
        }).then((err) => { if (!err) losts++; else failed++; return ackOp(o.id, !err, "mark_lost_" + err); }).catch(() => { failed++; return ackOp(o.id, false, "mark_lost_error"); });
      }); });
      return chain.then(() => ({ pushed, failed, notes, team, fees, emails, emailsHeld, emailSender, tasks, provisioned, esigns, losts, unhandled: unhandledOps.length }));
    }).catch(() => ({ pushed: 0, failed: 0, notes: 0, team: 0, fees: 0, emails: 0, tasks: 0, provisioned: 0, esigns: 0, unhandled: 0 }));
  }

  return loggedInProbe().then((ok) => {
    if (!ok) return { ok: false, loggedIn: false, tier: TIER, stops: 0, bookings: 0, notes: 0, photos: 0, error: "not signed in" };
    // SLOW lane: just the archive-inclusive projects history + prune. Routes/notes/outbox stay on the
    // fast lane, so they are intentionally NOT run here (no double work at the hourly tick).
    if (TIER === "full") {
      return pullProjects("full").then((bk) => {
        bk = bk || { saved: 0, partial: false };
        return { ok: !bk.partial, loggedIn: true, tier: "full", stops: 0, bookings: bk.saved || 0, notes: 0, photos: 0, emails: 0, tasks: 0, unhandled: 0, unmatched: [], partial: !!bk.partial, error: bk.partial ? "history incomplete" : null };
      }).catch((e) => ({ ok: false, loggedIn: true, tier: "full", stops: 0, bookings: 0, notes: 0, photos: 0, error: String(e).slice(0, 120) }));
    }
    // FAST lane: routes + active projects (scope:"active", never prunes) + notes + outbox drain.
    return Promise.all([pullRoutes(), pullProjects("active"), drainOutbox()]).then((res) => {
      const r = res[0] || { stops: 0, failed: 0, unmatched: [] };
      const bk = res[1] || { saved: 0, partial: false, notes: 0 };
      const ph = res[2] || { pushed: 0, failed: 0, emails: 0, tasks: 0, unhandled: 0 };
      return { ok: !r.failed && !bk.partial, loggedIn: true, tier: "active", stops: r.stops || 0, bookings: bk.saved || 0, notes: bk.notes || 0, photos: ph.pushed || 0, emails: ph.emails || 0, emailsHeld: ph.emailsHeld || 0, tasks: ph.tasks || 0, unhandled: ph.unhandled || 0, unmatched: r.unmatched || [], partial: !!bk.partial, error: r.failed ? "routes failed to save" : bk.partial ? "bookings incomplete" : null };
    }).catch((e) => ({ ok: false, loggedIn: true, tier: "active", stops: 0, bookings: 0, notes: 0, photos: 0, error: String(e).slice(0, 120) }));
  });
}
