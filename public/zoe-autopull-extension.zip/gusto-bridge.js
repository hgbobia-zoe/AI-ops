// Zoe Auto-Pull — Gusto bridge (isolated-world content script on app.gusto.com).
//
// The MAIN-world Gusto scripts (gusto.js = read sync, gusto-push.js = DRAFT hours push) must hook the app's
// own window.fetch, so they run in world MAIN — which has NO access to the chrome.* messaging APIs. This
// bridge is a normal isolated-world content script (it DOES have chrome.runtime), so it relays between those
// MAIN-world scripts and the background service worker. One-way, best-effort.
//
// READ sync (gusto.js): on its "posted" window message, relay {type:"zoe-gusto-posted"} so the background
// closes the dedicated on-demand sync tab.
//
// HOURS PUSH (gusto-push.js): when gusto-push posts "ready", CLAIM the push job for THIS exact tab from the
// background (it only hands the job to the tab it opened — a user's own Gusto tab never gets it). If a job
// comes back, post it into the MAIN world for gusto-push to execute. On gusto-push's "done" message, relay
// {type:"zoe-gusto-push-done"} so the background closes the dedicated push tab (watchdog reaps it otherwise).

(function () {
  if (window.__zoeGustoBridge) return;
  window.__zoeGustoBridge = true;

  function claimPushJob() {
    try {
      chrome.runtime.sendMessage({ type: "zoe-gusto-push-claim" }, (resp) => {
        try {
          if (chrome.runtime && chrome.runtime.lastError) return; // not our tab / channel closed
          const job = resp && resp.job;
          if (job) window.postMessage({ __zoeGustoPush: true, type: "job", job }, location.origin);
        } catch (e) { /* no-op */ }
      });
    } catch (e) { /* extension context gone */ }
  }

  // SUBMIT / CONFIRM-WIRE (gusto-submit.js): same claim handshake as the push, but a DIFFERENT marker +
  // channel so it never crosses wires with the hours push. The background only hands the job to the exact
  // tab it opened for the submit, so a user's own Gusto tab never gets it.
  function claimSubmitJob() {
    try {
      chrome.runtime.sendMessage({ type: "zoe-gusto-submit-claim" }, (resp) => {
        try {
          if (chrome.runtime && chrome.runtime.lastError) return;
          const job = resp && resp.job;
          if (job) window.postMessage({ __zoeGustoSubmit: true, type: "job", job }, location.origin);
        } catch (e) { /* no-op */ }
      });
    } catch (e) { /* extension context gone */ }
  }

  // CONTRACTOR staging (gusto-contractor.js): same claim handshake, its own marker + channel.
  function claimContractorJob() {
    try {
      chrome.runtime.sendMessage({ type: "zoe-gusto-contractor-claim" }, (resp) => {
        try {
          if (chrome.runtime && chrome.runtime.lastError) return;
          const job = resp && resp.job;
          if (job) window.postMessage({ __zoeGustoContractor: true, type: "job", job }, location.origin);
        } catch (e) { /* no-op */ }
      });
    } catch (e) { /* extension context gone */ }
  }

  window.addEventListener("message", (e) => {
    try {
      // Only trust same-window messages carrying our markers (ignore anything else the page posts).
      if (e.source !== window) return;
      const d = e.data;
      if (!d) return;

      // READ sync completed → close the dedicated sync tab.
      if (d.__zoeGusto === true && d.type === "posted") {
        chrome.runtime.sendMessage({ type: "zoe-gusto-posted", ok: !!d.ok });
        return;
      }

      // HOURS PUSH handshakes.
      if (d.__zoeGustoPush === true) {
        if (d.type === "ready") { claimPushJob(); return; }
        // Signed-out: gusto-push wants this hidden tab brought to the front (+ detached from the watchdog) so
        // the operator can sign in to Gusto. Relay to the background, which owns chrome.tabs/windows.
        if (d.type === "reveal") { chrome.runtime.sendMessage({ type: "zoe-gusto-push-reveal" }); return; }
        if (d.type === "done") { chrome.runtime.sendMessage({ type: "zoe-gusto-push-done", ok: !!d.ok }); return; }
      }

      // CONTRACTOR staging handshakes (gusto-contractor.js).
      if (d.__zoeGustoContractor === true) {
        if (d.type === "ready") { claimContractorJob(); return; }
        if (d.type === "reveal") { chrome.runtime.sendMessage({ type: "zoe-gusto-contractor-reveal" }); return; }
        if (d.type === "done") { chrome.runtime.sendMessage({ type: "zoe-gusto-contractor-done", ok: !!d.ok }); return; }
      }

      // SUBMIT / CONFIRM-WIRE handshakes (gusto-submit.js). Same shape as the push, separate channel.
      if (d.__zoeGustoSubmit === true) {
        if (d.type === "ready") { claimSubmitJob(); return; }
        if (d.type === "reveal") { chrome.runtime.sendMessage({ type: "zoe-gusto-submit-reveal" }); return; }
        if (d.type === "done") { chrome.runtime.sendMessage({ type: "zoe-gusto-submit-done", ok: !!d.ok }); return; }
      }
    } catch (err) {
      /* extension context gone / message channel closed — nothing to do */
    }
  });
})();
